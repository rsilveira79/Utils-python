# -*- coding: utf-8 -*-
"""
Created on Fri Mar 31 14:46:04 2017

@author: tassonis
"""

import json
import sounddevice as sd
import subprocess
from os.path import join, dirname
from scipy.io import wavfile
from watson_developer_cloud import SpeechToTextV1
from watson_developer_cloud import ConversationV1
from watson_developer_cloud import TextToSpeechV1

#############################
#Speech-to-text service setup
speech_to_text = SpeechToTextV1(
    username='35ccbb53-a1a9-4cba-9585-b0c2666a45b3',
    password='4WezaVGN3IV5',
    x_watson_learning_opt_out=False
)


#############################
#Conversation service setup
conversation = ConversationV1(
    username='9f15c278-3625-4107-9904-26c1d2b5057e',
    password='4HwWTL2uqdfp',
    version='2016-09-20')

#workspace_id: this is the Robotics Workspace ID
workspace_id = 'eef52e99-81e9-4c9f-bdae-a9fe541eb552'


#############################
#Text-to-speech service setup
text_to_speech = TextToSpeechV1(
    username='77bb0d5c-31ea-4a4a-bb36-175779e26f24',
    password='bIkfVE3ZIRLt',
    x_watson_learning_opt_out=True)  # Optional flag


#############################
#Capture audio from microphone
fs=22050
duration = 3  # seconds
myrecording = sd.rec(duration * fs, samplerate=fs, channels=1,dtype='int32')
print "Recording Audio..."
sd.wait()
print "Stopped."
#Convert numpy array to wav
wavfile.write('./temp.wav', rate=fs, data=myrecording)


#############################
#Apply audio data (wav file) to SPEECH_TO_TEXT service
speech_to_text.get_model('en-US_BroadbandModel')

with open(join(dirname(__file__), './temp.wav'), 'rb') as audio_file:
    resp_string = json.dumps(speech_to_text.recognize(
        audio_file, content_type='audio/wav', timestamps=True,
        word_confidence=True), indent=2)
    resp_dict = json.loads(resp_string)
    #Get first entry of results array, first entry of alternatives and
    #  then the transcript
    if resp_dict['results']:    
        transcript = resp_dict['results'][0]['alternatives'][0]['transcript']
        print(transcript)
    else:
        print('No transcript')		
        exit()

#############################
#Apply transcript text to CONVERSATION service
conv_analysis = conversation.message(workspace_id=workspace_id, message_input={
    'text': transcript})
#takes first intent
intent = ""
if conv_analysis['intents']:
    intent      = conv_analysis['intents'][0]['intent']
    intent_conf = conv_analysis['intents'][0]['confidence']
    print(intent)
    print(intent_conf)
#takes first entity
entity = ""
entity_val = ""
if conv_analysis['entities']:
    entity      = conv_analysis['entities'][0]['entity']
    entity_val  = conv_analysis['entities'][0]['value']
    print(entity)
    print(entity_val)

#Process response
if (intent == 'StartCast'):
    response = 'Ok. Sharing the screen with the living room'
elif (intent == 'StopCast'):
    response = 'Ok. Your screen is no longer being shared'
elif (intent == 'ReadEmail') and (entity == 'Sender'):
    response = 'Ok. Reading e-mails from ' + entity_val;
elif (intent == 'ReadEmail'):
    response = 'Ok. You may have new e-mails';
elif (intent == 'PlayMusic'):
    response = 'Ok. Playing your favorite songs'
else:
    response = 'Sorry, I did not understand'
print response

#############################
#Apply text data to TEXT_TO_SPEECH service
#To list all available voices
#print(json.dumps(text_to_speech.voices(), indent=2))
with open(join(dirname(__file__), 'output.wav'),
          'wb') as audio_file:
    audio_file.write(
        text_to_speech.synthesize(response, accept='audio/wav',
                                  voice="en-US_LisaVoice"))
p = subprocess.Popen(["aplay", "output.wav"], stdout=subprocess.PIPE)

