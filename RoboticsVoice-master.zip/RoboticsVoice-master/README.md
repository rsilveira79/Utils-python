# RoboticsVoice
Python code to access IBM Watson services for speech-to-text, conversation and text-to-speech services.

Speech-to-text and text-to-speech are self-explained.
Conversation contains a definition of intents and entities that can be extracted from what the user says, bringing semantic meaning to a simple text line. Since each intent can be trained with many ways of saying the same thing, it also brings flexibility to the application.

##Setup
###Make sure you have all dependencies ok:
```
sudo apt-get install build-essential gfortran libatlas-base-dev python-pip python-dev
sudo apt-get install virtualenv
```

###Create a new virtual environment:
```
mkdir manea-env
virtualenv manea-env
cd manea-env
source bin/activate
```

###Install python libraries:
```
pip install -r requirements.txt
```

##Test it

Run 'python voice_control.py' and try the following commands:
```
Read my e-mails
Read messages
Play some music
Share my display with living room
```
