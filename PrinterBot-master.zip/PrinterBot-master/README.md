# Printer Bot

An end-to-end implementation of Slack chatbot using Word2Vec and WMD (Word Movers Distance). The main idea of this implementation, is to have a method that will use only local frameworks, without any external and third-party API for natural language processing (NLP).

The system overall architecture can be seen below:

![](docs/chatbot_architecture.png?raw=true)

# Getting Started

This section describes how to install the requirements and vector model required to execute the PrinterBot.

### 1. Download the Pre-Trained Word2Vec Model

To install it, first download the [Word2Vec model pre-trained](https://drive.google.com/file/d/0B7XkCwpI5KDYNlNUTTlSS21pQmM/edit?usp=sharing) on the Google News dataset.
After downloading it, decompress it and place it inside a new `model` folder, you can do
that with the commands below (assuming you downloaded the vector model on the root directory of the repository):

    ~# mkdir model
    ~# gzip -d ../GoogleNews-vectors-negative300.bin.gz

### 2. Install Python and Python requirements

To install Python on Ubuntu:

    ~# sudo apt-get -y install python python-dev python-pip

To install Python requirements, just use `pip` Python installer using the `pip-requirements.txt` requirements file present in the repository:

    ~# sudo pip install -r pip-requirements.txt

After that, you just need to download the Spacy NLP English models:

    ~# python -m spacy.en.download all

From now you, you'll be able to execute the bot.   

### How to execute it ?

To execute the bot application, you just need to execute the following command:

    ~# python bot.py

After that, it will take some time to read the word2vec model and then it will become online on the Slack channel.

**Note:** you need to configure the auth token and other configs in the `bot.py` file in order to put the Bot on another Slack channel.