import time

import spacy as sp
from gensim import models
from easysnmp import Session
from slackclient import SlackClient


class SlackBot(object):
    READ_WEBSOCKET_DELAY = 0.2

    def __init__(self, key, bot_id):
        self.slack_key = key
        self.bot_id = bot_id
        self.at_bot = "<@" + bot_id + ">"
        self.slack_client = SlackClient(key)

    def run(self):
        if self.slack_client.rtm_connect():
            print("Slack bot connected and running.")
            while True:
                read_data = self.slack_client.rtm_read()
                command, channel = self.parse_output(read_data)
                if command and channel:
                    self.handle_command(command, channel)
                time.sleep(SlackBot.READ_WEBSOCKET_DELAY)
        else:
            raise RuntimeError("Connection failed. Check token or bot ID.")

    def handle_command(self, command, channel):
        raise NotImplementedError("Please Implement this method.")

    def parse_output(self, slack_rtm_output):
        out_list = slack_rtm_output
        if out_list and len(out_list) > 0:
            for output in out_list:
                if output and 'text' in output and \
                   self.at_bot in output['text']:
                    cmd = output['text'].split(self.at_bot)[1] \
                              .strip().lower()
                    channel = output['channel']
                    return cmd, channel
        return None, None


class PrinterBot(SlackBot):
    SNMP_PRINT_COUNT = "iso.3.6.1.2.1.43.10.2.1.4.1.1"
    SNMP_PRINTER_MODEL = "iso.3.6.1.2.1.25.3.2.1.3.1"

    SNMP_TONER_BLACK = "iso.3.6.1.2.1.43.11.1.1.9.1.1"
    SNMP_TONER_CYAN = "iso.3.6.1.2.1.43.11.1.1.9.1.2"
    SNMP_TONER_MAGENTA = "iso.3.6.1.2.1.43.11.1.1.9.1.3"
    SNMP_TONER_YELLOW = "iso.3.6.1.2.1.43.11.1.1.9.1.4"
    LOW_CONFIDENCE_THR = 1.2

    ORDINALS = {"first": 1,
                "second": 2,
                "third": 3,
                "fourth": 4,
                "fifth": 5,
                "sixth": 6}

    def __init__(self, model, printer_ip, key, bot_id):
        self.en_nlp = sp.load('en')
        self.model = model
        self.sentences = {
            "what is the status of the printer": self.get_printer_status,
            "tell me the status of the printer": self.get_printer_status,

            "what is your name ?": self.get_bot_name,
            "tell me your name": self.get_bot_name,

            "how many pages did you printed ?": self.get_printer_count,
            "tell me the number of pages you printed": self.get_printer_count,

            "what is your model ?": self.get_printer_model,
            "tell me what is your model": self.get_printer_model,
            "tell me your model": self.get_printer_model,

            "what is the status of the tray one ?": self.get_tray_status,
            "tell me the status of the tray one ?": self.get_tray_status,

            "what is the status of the first tray ?": self.get_tray_status,
            "tell me the status of the first tray ?": self.get_tray_status,

            "what is the status of the toner ?": self.get_toner_status,
            "tell me your toner status": self.get_toner_status,
            "tell me your toner levels": self.get_toner_status,
            "what are the toner levels ?": self.get_toner_status,
        }
        self.msg_not_understand = {
            "text": "Sorry, I wasn't able to understand what you said.",
            "attachments": None
        }

        self.printer_session = Session(hostname=printer_ip,
                                       community='public',
                                       version=2)
        super(PrinterBot, self).__init__(key, bot_id)

    def get_bot_name(self, command, channel):
        message = {
            "text": "My name is Print Bot ! :tada:",
            "attachments": None,
        }
        return message

    def get_printer_status(self, command, channel):
        message = {
            "text": "The printer is operating with status *ready*.",
            "attachments": None,
        }
        return message

    def get_tray_status(self, command, channel):
        en_doc = self.en_nlp(command)
        ents = en_doc.ents

        if len(ents) > 1:
            return self.msg_not_understand

        try:
            tray_ent = ents[0]
        except:
            return self.msg_not_understand

        num_types = ["CARDINAL", "ORDINAL"]
        if tray_ent.label_ not in num_types:
            message = {
                "text": "Please use cardinal numbers to specify the tray, "
                        "such as '1', or ordinal such as 'first'.",
                "attachments": None,
            }
            return message

        if tray_ent.label_ == 'ORDINAL':
            tray_number = PrinterBot.ORDINALS[tray_ent.text]
        elif tray_ent.label_ == 'CARDINAL':
            try:
                tray_number = int(tray_ent.text)
            except:
                message = {
                    "text": "Please use cardinal numbers to specify the tray, "
                            "such as '1', or ordinal such as 'first'.",
                    "attachments": None,
                }
                return message
        else:
            return self.msg_not_understand

        message = {
            "text": "The status of the tray number {} "
                    "is *ready*.".format(tray_number),
            "attachments": None,
        }
        return message

    def get_printer_count(self, command, channel):
        out = self.printer_session.get(PrinterBot.SNMP_PRINT_COUNT)
        message = {
            "text": "Hi ! I already printed {} pages !".format(out.value),
            "attachments": None,
        }
        return message

    def get_printer_model(self, command, channel):
        out = self.printer_session.get(PrinterBot.SNMP_PRINTER_MODEL)
        message = {
            "text": "Hi ! Im the {}, at your command.".format(out.value),
            "attachments": None,
        }
        return message

    def get_toner_status(self, command, channel):
        black = self.printer_session.get(PrinterBot.SNMP_TONER_BLACK)
        cyan = self.printer_session.get(PrinterBot.SNMP_TONER_CYAN)
        magenta = self.printer_session.get(PrinterBot.SNMP_TONER_MAGENTA)
        yellow = self.printer_session.get(PrinterBot.SNMP_TONER_YELLOW)

        attachments = [
                {
                    "text": "Toner Levels",
                    "thumb_url": "http://www.www8-hp.com/emea_middle_east/en/images/icon-exceptional-quality-3_tcm_163_2054135.png",
                    "fields": [
                        {
                            "title": "Black",
                            "value": "{}%".format(int(black.value)),
                            "short": True
                        },
                        {
                            "title": "Cyan",
                            "value": "{}%".format(int(cyan.value)),
                            "short": True
                        },
                        {
                            "title": "Magenta",
                            "value": "{}%".format(int(magenta.value)),
                            "short": True
                        },
                        {
                            "title": "Yellow",
                            "value": "{}%".format(int(yellow.value)),
                            "short": True
                        }
                    ],
                }
            ]

        message = {
            "text": "Hello, here is the toner level report:",
            "attachments": attachments,
        }

        return message

    def handle_command(self, command, channel):
        min_distance = float("+inf")
        closest_action = None

        print "-" * 40
        for ask, action in self.sentences.iteritems():
            wmd_distance = self.model.wmdistance(command, ask)
            print "[{}] -> [{}]".format(command, ask)
            print "Distance: {}".format(wmd_distance)

            if wmd_distance < min_distance:
                min_distance = wmd_distance
                closest_action = action

        if callable(closest_action):
            closest_action = closest_action(command, channel)

        if min_distance > PrinterBot.LOW_CONFIDENCE_THR:
            self.slack_client.api_call("chat.postMessage", channel=channel,
                                       text=self.msg_not_understand["text"],
                                       as_user=True)
            return

        self.slack_client.api_call("chat.postMessage", channel=channel,
                                   text=closest_action["text"], as_user=True,
                                   attachments=closest_action["attachments"])
        return


def run_main():
    # Configuration section, Slack bot key, etc
    bot_key = "xoxb-130954812342-gyhJFtX4fmFTBYFn1jW1DEmH"
    bot_id = "U3UU2PWA2"
    printer_ip = "15.29.229.165"

    w2v_model = models.Word2Vec.load_word2vec_format(
                "model/GoogleNews-vectors-negative300.bin",
                binary=True)

    bot = PrinterBot(w2v_model, printer_ip,
                     bot_key, bot_id)
    bot.run()

if __name__ == "__main__":
    run_main()
