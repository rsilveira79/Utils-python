from slackclient import SlackClient

key = "xoxb-130954812342-gyhJFtX4fmFTBYFn1jW1DEmH"
BOT_NAME = "printbot"
BOT_ID = "U3UU2PWA2"

slack_client = SlackClient(key)

def run_main():
    api_call = slack_client.api_call("users.list")
    if api_call.get('ok'):
        # retrieve all users so we can find our bot
        users = api_call.get('members')
        for user in users:
            if 'name' in user and user.get('name') == BOT_NAME:
                print("Bot ID for '" + user['name'] + "' is " + user.get('id'))
    else:
        print("could not find bot user with the name " + BOT_NAME)

if __name__ == "__main__":
    run_main()
