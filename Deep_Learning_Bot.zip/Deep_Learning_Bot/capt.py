from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2


def run_main():
    camera = PiCamera()
    camera.resolution = (640, 480)
    camera.framerate = 32
    raw_capture = PiRGBArray(camera, size=(640, 480))

    time.sleep(0.5)

    for frame in camera.capture_continuous(raw_capture, format="bgr", use_video_port=True):
        image = frame.array
        raw_capture.truncate(0)

        resized_frame = cv2.resize(image, (224, 224))
        frame = resized_frame.transpose(2, 1, 0)
        print frame.shape





    

    



if __name__ == '__main__':
    run_main()

