import RPi.GPIO as GPIO
from time import sleep

Motor1A = 4
Motor1B = 3

Motor2A = 23
Motor2B = 24

Motor1E = 12
Motor2E = 13

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(Motor1A, GPIO.OUT)
GPIO.setup(Motor1B, GPIO.OUT)
GPIO.setup(Motor1E, GPIO.OUT)
GPIO.setup(Motor2A, GPIO.OUT)
GPIO.setup(Motor2B, GPIO.OUT)
GPIO.setup(Motor2E, GPIO.OUT)

motorR = GPIO.PWM(Motor1E, 100)
motorL = GPIO.PWM(Motor2E, 100)

motorR.start(0)
motorL.start(0)


def checkSpeed(speed):
    #if speed < 25:
    #    speed = 25
    #if speed > 100:
    #    speed = 100
    print("Speed is: " + str(speed))
    return speed


def goStraight(speed):
    speed = checkSpeed(speed)
    print("Going straigh with speed: "+str(speed))
    GPIO.output(Motor1A, GPIO.HIGH)
    GPIO.output(Motor1B, GPIO.LOW)
    GPIO.output(Motor2A, GPIO.HIGH)
    GPIO.output(Motor2B, GPIO.LOW)

    motorR.ChangeDutyCycle(speed)
    motorL.ChangeDutyCycle(speed + 9)


def stop():
    print("Stoping")
    motorL.ChangeDutyCycle(0)
    motorR.ChangeDutyCycle(0)


def exitAndClean():
    print("Exiting")
    motorR.stop()
    motorL.stop()
    GPIO.cleanup()
    exit()


def cleanNoExit():
    print("Exiting")
    motorR.stop()
    motorL.stop()
    GPIO.cleanup()


def goBack(speed):
    speed = checkSpeed(speed)
    print("Going back with speed: "+str(speed))
    GPIO.output(Motor1A, GPIO.LOW)
    GPIO.output(Motor1B, GPIO.HIGH)
    GPIO.output(Motor2A, GPIO.LOW)
    GPIO.output(Motor2B, GPIO.HIGH)
    motorR.ChangeDutyCycle(speed)
    motorL.ChangeDutyCycle(speed)


def turnRight(speed):
    speed = checkSpeed(speed)
    print("Turning right with speed: "+str(speed))
    GPIO.output(Motor1A, GPIO.HIGH)
    GPIO.output(Motor1B, GPIO.LOW)
    GPIO.output(Motor2A, GPIO.HIGH)
    GPIO.output(Motor2B, GPIO.LOW)
    motorR.ChangeDutyCycle(speed/3)
    motorL.ChangeDutyCycle(speed)


def turnLeft(speed):
    speed = checkSpeed(speed)
    print("Turning left with speed: "+str(speed))
    GPIO.output(Motor1A, GPIO.HIGH)
    GPIO.output(Motor1B, GPIO.LOW)
    GPIO.output(Motor2A, GPIO.HIGH)
    GPIO.output(Motor2B, GPIO.LOW)
    motorR.ChangeDutyCycle(speed)
    motorL.ChangeDutyCycle(speed/3)


def fastLeft(speed):
    speed = checkSpeed(speed)
    print("Turning left with speed: "+str(speed))
    GPIO.output(Motor1A, GPIO.HIGH)
    GPIO.output(Motor1B, GPIO.LOW)
    GPIO.output(Motor2A, GPIO.LOW)
    GPIO.output(Motor2B, GPIO.HIGH)
    motorR.ChangeDutyCycle(speed)
    motorL.ChangeDutyCycle(speed)


def customSpeed(direction, left,  right):
    right = int(right)
    left = int(left)
    if direction == "f":
        GPIO.output(Motor1A, GPIO.HIGH)
        GPIO.output(Motor1B, GPIO.LOW)
        GPIO.output(Motor2A, GPIO.HIGH)
        GPIO.output(Motor2B, GPIO.LOW)
        motorR.ChangeDutyCycle(right)
        motorL.ChangeDutyCycle(left)
    else:
        GPIO.output(Motor1A, GPIO.LOW)
        GPIO.output(Motor1B, GPIO.HIGH)
        GPIO.output(Motor2A, GPIO.LOW)
        GPIO.output(Motor2B, GPIO.HIGH)
        motorR.ChangeDutyCycle(right)
        motorL.ChangeDutyCycle(left)
    ans = "Going "+ ("Forward" if direction == "f" else "Back") +". Left: "+str(left)+". Right: "+str(right)



#sleep(0.5)

#turnRight(25)
#fastLeft(100)
goStraight(30)
#goBack(35)
sleep(1.5)

exitAndClean()


'''
customSpeed("f",100,100)
sleep(1)
customSpeed("b",100,100)
print("10%")
motorR.ChangeDutyCycle(10)
motorL.ChangeDutyCycle(10)
sleep(1)
print("30%")
motorR.ChangeDutyCycle(30)
motorL.ChangeDutyCycle(30)
sleep(1)
print("50%")
motorR.ChangeDutyCycle(50)
motorL.ChangeDutyCycle(50)
sleep(1)
print("80%")
motorR.ChangeDutyCycle(80)
motorL.ChangeDutyCycle(80)
sleep(1)
print("100%")
motorR.ChangeDutyCycle(100)
motorL.ChangeDutyCycle(100)
sleep(1)
print("0%")
motorR.ChangeDutyCycle(0)
motorL.ChangeDutyCycle(0)
sleep(1)
'''
