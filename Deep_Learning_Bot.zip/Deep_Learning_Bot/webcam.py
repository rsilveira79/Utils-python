import numpy as np
from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
from StringIO import StringIO

from botcontrol import DrunkBot
import requests
from fractions import Fraction

def run_main():
    print "Initializing Pi Camera..."
    cap = cv2.VideoCapture(0)

    print "Initializing engines..."
    motor_left = (23, 24, 13)
    motor_right = (4, 3, 12)
    bot_control = DrunkBot(motor_left, motor_right,
                           adjust_left=10, adjust_right=0)
    bot_control.setup()
    #bot_control.step_forward()

    print "Main loop..."
    while True:
        ret, frame = cap.read()
        print "Captured !"

        if not ret:
            print "Not captured !"
            continue

        resized_frame = cv2.resize(frame, (224, 224))
        # 224, 224, 3 -> 3 224, 224
        frame = resized_frame.transpose(2, 0, 1)
        #print "Frame captured:", frame.shape, type(frame), frame.dtype

        tmp = StringIO()
        np.save(tmp, frame)
        tmp.seek(0)
        #print tmp

        # 1 - Upload
        print "uploading..."
        files = {'upload_image': ('image.jpg', tmp)}
        r = requests.post('http://10.0.0.123:5002/getinstruction', files=files)
        predicted_action = int(r.json()['result'])

        print predicted_action

        if predicted_action == 0:
            bot_control.step_left()

        if predicted_action == 1:
            bot_control.step_right()

        if predicted_action == 2:
            bot_control.step_forward()

        time.sleep(0.5)

    cap.release()
    cv2.destroyAllWindows()
    bot_control.cleanup()

if __name__ == '__main__':
    run_main()
