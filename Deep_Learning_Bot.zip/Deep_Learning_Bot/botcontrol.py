import RPi.GPIO as GPIO
import time
import requests


class DrunkBot(object):
    def __init__(self, motor_left, motor_right,
                 adjust_left, adjust_right):
        # pin1, pin2, pwm
        self.motor_left = motor_left
        self.motor_right = motor_right
        self.adjust_left = adjust_left
        self.adjust_right = adjust_right

    def setup(self):
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)

        GPIO.setup(self.motor_left[0], GPIO.OUT)
        GPIO.setup(self.motor_left[1], GPIO.OUT)
        GPIO.setup(self.motor_left[2], GPIO.OUT)

        GPIO.setup(self.motor_right[0], GPIO.OUT)
        GPIO.setup(self.motor_right[1], GPIO.OUT)
        GPIO.setup(self.motor_right[2], GPIO.OUT)

        self.motor_l = GPIO.PWM(self.motor_left[2], 100)
        self.motor_r = GPIO.PWM(self.motor_right[2], 100)

        self.motor_l.start(0)
        self.motor_r.start(0)

    def forward(self, speed=25):
        self.motor_l.ChangeDutyCycle(speed + self.adjust_left)
        self.motor_r.ChangeDutyCycle(speed + self.adjust_right)

        GPIO.output(self.motor_left[1], GPIO.LOW)
        GPIO.output(self.motor_left[0], GPIO.HIGH)

        GPIO.output(self.motor_right[1], GPIO.LOW)
        GPIO.output(self.motor_right[0], GPIO.HIGH)

    def backward(self, speed=25):
        self.motor_l.ChangeDutyCycle(speed + self.adjust_left)
        self.motor_r.ChangeDutyCycle(speed + self.adjust_right)

        GPIO.output(self.motor_left[0], GPIO.LOW)
        GPIO.output(self.motor_left[1], GPIO.HIGH)

        GPIO.output(self.motor_right[0], GPIO.LOW)
        GPIO.output(self.motor_right[1], GPIO.HIGH)

    def stop(self):
        self.motor_l.ChangeDutyCycle(0)
        self.motor_r.ChangeDutyCycle(0)

        GPIO.output(self.motor_left[0], GPIO.LOW)
        GPIO.output(self.motor_left[1], GPIO.LOW)

        GPIO.output(self.motor_right[0], GPIO.LOW)
        GPIO.output(self.motor_right[1], GPIO.LOW)

    def turn_left(self, speed):
        self.motor_l.ChangeDutyCycle(speed + self.adjust_left)
        self.motor_r.ChangeDutyCycle(speed + self.adjust_right)

        GPIO.output(self.motor_left[0], GPIO.LOW)
        GPIO.output(self.motor_left[1], GPIO.HIGH)

        GPIO.output(self.motor_right[0], GPIO.HIGH)
        GPIO.output(self.motor_right[1], GPIO.LOW)


    def turn_right(self, speed):
        self.motor_l.ChangeDutyCycle(speed + self.adjust_left)
        self.motor_r.ChangeDutyCycle(speed + self.adjust_right)

        GPIO.output(self.motor_left[0], GPIO.HIGH)
        GPIO.output(self.motor_left[1], GPIO.LOW)

        GPIO.output(self.motor_right[0], GPIO.LOW)
        GPIO.output(self.motor_right[1], GPIO.HIGH)


    def cleanup(self):
        GPIO.cleanup()

    def step_forward(self):
        self.forward(30)
        #time.sleep(1.0)
        time.sleep(0.5)
        self.stop()

    def step_backward(self):
        self.backward(30)
        time.sleep(1.0)
        self.stop()

    def step_right(self):
        self.turn_right(40)
        #time.sleep(0.2)
        time.sleep(0.1)
        self.stop()

    def step_left(self):
        self.turn_left(40)
        #time.sleep(0.2)
        time.sleep(0.1)
        self.stop()


def run_main():
    motor_left = (23, 24, 13)
    motor_right = (4, 3, 12)

    bot_control = DrunkBot(motor_left, motor_right,
                           adjust_left=10, adjust_right=0)
    bot_control.setup()

    
    for x in xrange(5):
        bot_control.step_forward()
        bot_control.step_right()

    bot_control.cleanup()

if __name__ == '__main__':
    run_main()
